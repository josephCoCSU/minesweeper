﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minesweeper
{
    class Program
    {
        static void Main(string[] args)
        {

            Grid grid = new Grid(5, 5, 5);
            String finished = "";
            grid.Show();

            // loops until player quits or until player opens a mine
            while(finished != "n")
            {
                int row;
                int column;
                Console.Write("Enter a Row: ");
                row = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter a Column: ");
                column = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("You entered '{0}'", row);

                if (grid.Open(row, column))
                    break;
                System.Console.WriteLine("Continue? y/n : ");
                finished = (Console.ReadLine());
            }

        }
    }
}
